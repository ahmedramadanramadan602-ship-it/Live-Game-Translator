package com.livegametranslator.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.livegametranslator.app.translation.TranslationMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "translator_settings")

data class AppSettings(
    val mode: TranslationMode = TranslationMode.LOCAL_ONLY,
    val localFallback: Boolean = true
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val MODE = stringPreferencesKey("translation_mode")
        val FALLBACK = booleanPreferencesKey("local_fallback")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val mode = runCatching {
            TranslationMode.valueOf(prefs[Keys.MODE] ?: TranslationMode.LOCAL_ONLY.name)
        }.getOrDefault(TranslationMode.LOCAL_ONLY)
        AppSettings(mode, prefs[Keys.FALLBACK] ?: true)
    }

    suspend fun setMode(mode: TranslationMode) {
        context.dataStore.edit { it[Keys.MODE] = mode.name }
    }

    suspend fun setFallback(enabled: Boolean) {
        context.dataStore.edit { it[Keys.FALLBACK] = enabled }
    }
}
