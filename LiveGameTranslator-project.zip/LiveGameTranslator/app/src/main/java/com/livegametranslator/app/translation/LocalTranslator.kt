package com.livegametranslator.app.translation

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class LocalTranslator {
    private val translator by lazy {
        val source = TranslateLanguage.ENGLISH
            ?: error("لغة المصدر الإنجليزية غير متاحة في إصدار ML Kit الحالي.")
        val target = TranslateLanguage.ARABIC
            ?: error("لغة الهدف العربية غير مدعومة في إصدار ML Kit الحالي.")
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(target)
                .build()
        )
    }

    suspend fun translate(text: String): String = suspendCancellableCoroutine { continuation ->
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { result ->
                        if (continuation.isActive) continuation.resume(result)
                    }
                    .addOnFailureListener { error ->
                        if (continuation.isActive) continuation.resumeWithException(error)
                    }
            }
            .addOnFailureListener { error ->
                if (continuation.isActive) continuation.resumeWithException(error)
            }
    }

    fun close() = translator.close()
}
