package com.livegametranslator.app.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.livegametranslator.app.ocr.ScreenTextRecognizer
import com.livegametranslator.app.overlay.TranslationOverlay
import com.livegametranslator.app.translation.LocalTranslator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.util.LruCache

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.livegametranslator.app.START"
        const val ACTION_STOP = "com.livegametranslator.app.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_MODE = "mode"
        const val EXTRA_FALLBACK = "fallback"
        private const val CHANNEL_ID = "capture_session"
        private const val NOTIFICATION_ID = 41
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var recognizer: ScreenTextRecognizer? = null
    private var translator: LocalTranslator? = null
    private var overlay: TranslationOverlay? = null
    private val translationCache = LruCache<String, String>(100)
    private val latestFrames = Channel<Bitmap>(
        capacity = Channel.CONFLATED,
        onUndeliveredElement = { bitmap -> if (!bitmap.isRecycled) bitmap.recycle() }
    )
    private var currentMode = "LOCAL_ONLY"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        overlay = TranslationOverlay(this)
        recognizer = ScreenTextRecognizer()
        translator = LocalTranslator()
        serviceScope.launch {
            for (bitmap in latestFrames) {
                try {
                    val text = withContext(Dispatchers.Default) { recognizer?.recognize(bitmap).orEmpty() }
                    if (text.isNotBlank()) {
                        val cached = translationCache.get(text)
                        val translated = cached ?: withContext(Dispatchers.IO) {
                            translator?.translate(text).orEmpty()
                        }.also { result ->
                            if (result.isNotBlank()) translationCache.put(text, result)
                        }
                        if (translated.isNotBlank()) overlay?.show(translated)
                    }
                } catch (_: Exception) {
                    // A failed frame is skipped; the next fresh frame can be processed.
                } finally {
                    if (!bitmap.isRecycled) bitmap.recycle()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSession()
            ACTION_START -> {
                currentMode = intent.getStringExtra(EXTRA_MODE) ?: "LOCAL_ONLY"
                startForeground(NOTIFICATION_ID, buildNotification())
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                else intent.getParcelableExtra(EXTRA_RESULT_DATA)
                if (data == null) {
                    stopSession()
                } else startProjection(resultCode, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            workerThread = HandlerThread("ScreenCapture").also { it.start() }
            workerHandler = Handler(workerThread!!.looper)
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                val bitmap = imageToBitmap(image)
                image.close()
                if (bitmap != null) {
                    if (!latestFrames.trySend(bitmap).isSuccess) bitmap.recycle()
                }
            }, workerHandler)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSession() }
            }, workerHandler)
            virtualDisplay = projection?.createVirtualDisplay(
                "LiveGameTranslator",
                width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface, null, workerHandler
            )
        } catch (_: Exception) {
            stopSession()
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? = runCatching {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        cropped
    }.getOrNull()

    private fun stopSession() {
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() }
        imageReader = null
        runCatching { projection?.stop() }
        projection = null
        overlay?.hide()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ترجم لعبتك")
            .setContentText("جلسة التقاط الشاشة قيد التشغيل")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "جلسة الترجمة", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        stopSession()
        latestFrames.close()
        recognizer?.close()
        translator?.close()
        workerThread?.quitSafely()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
