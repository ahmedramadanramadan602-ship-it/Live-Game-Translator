package com.livegametranslator.app.translation

enum class TranslationMode(val label: String, val description: String) {
    LOCAL_ONLY("Local Only", "ترجمة محلية دون خدمات AI."),
    LOCAL_AI("Local + AI", "يعرض المحلي أولاً؛ تحسين AI غير موصول في هذا الإصدار."),
    AI_ONLY("AI Only", "يتطلب تكامل خادم AI؛ يستخدم المحلي كاحتياطي عند تفعيله.")
}
