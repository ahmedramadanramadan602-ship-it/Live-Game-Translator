package com.livegametranslator.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.livegametranslator.app.capture.CaptureService
import com.livegametranslator.app.data.AppSettings
import com.livegametranslator.app.data.SettingsStore
import com.livegametranslator.app.translation.TranslationMode
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { TranslatorHome() } }
    }
}

@Composable
private fun TranslatorHome() {
    val context = LocalContext.current
    val activity = context as Activity
    val store = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()
    val settings by store.settings.collectAsState(initial = AppSettings())
    var message by remember { mutableStateOf("جاهز. ابدأ جلسة جديدة عندما تكون داخل اللعبة أو قبل فتحها.") }

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(context, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                putExtra(CaptureService.EXTRA_MODE, settings.mode.name)
                putExtra(CaptureService.EXTRA_FALLBACK, settings.localFallback)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
            message = "تم منح إذن التقاط الشاشة. بدأت محاولة تشغيل الجلسة."
        } else {
            message = "لم يتم منح إذن التقاط الشاشة؛ لم يبدأ الالتقاط."
        }
    }

    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("ترجم لعبتك", style = MaterialTheme.typography.headlineMedium)
        Text("Live Game Translator", style = MaterialTheme.typography.titleMedium)
        Text("ترجمة النصوص الظاهرة على الشاشة أثناء اللعب.")
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("جلسة الترجمة", style = MaterialTheme.typography.titleLarge)
                Text(message)
                Button(
                    onClick = {
                        if (!Settings.canDrawOverlays(context)) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                            message = "اسمح بالظهور فوق التطبيقات، ثم اضغط بدء الجلسة مرة أخرى."
                        } else {
                            if (Build.VERSION.SDK_INT >= 33) {
                                notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            }
                            val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            projectionLauncher.launch(manager.createScreenCaptureIntent())
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("بدء جلسة الترجمة") }
                OutlinedButton(
                    onClick = {
                        context.startService(Intent(context, CaptureService::class.java).apply {
                            action = CaptureService.ACTION_STOP
                        })
                        message = "تم إرسال طلب إيقاف الجلسة."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("إيقاف الجلسة") }
            }
        }
        Text("وضع الترجمة", style = MaterialTheme.typography.titleLarge)
        TranslationMode.entries.forEach { mode ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(mode.label, style = MaterialTheme.typography.titleMedium)
                    Text(mode.description, style = MaterialTheme.typography.bodySmall)
                }
                RadioButton(
                    selected = settings.mode == mode,
                    onClick = { scope.launch { store.setMode(mode) } }
                )
            }
        }
        HorizontalDivider()
        Text("الإعدادات", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("السماح بالترجمة المحلية الاحتياطية")
                Text("تستخدم عند فشل مسار AI مستقبلاً.", style = MaterialTheme.typography.bodySmall)
            }
            Switch(
                checked = settings.localFallback,
                onCheckedChange = { scope.launch { store.setFallback(it) } }
            )
        }
        Text(
            "ملاحظة: إصدار MVP الحالي ينفّذ التقاط الشاشة وOCR والترجمة المحلية والعرض العائم. تكامل Gemini غير مفعّل ولا يرسل أي بيانات.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
